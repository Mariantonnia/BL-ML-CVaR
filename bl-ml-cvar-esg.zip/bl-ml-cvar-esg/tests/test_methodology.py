"""Unit tests that pin each component to the equation of the paper."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from blmlcvar import black_litterman as bl  # noqa: E402
from blmlcvar.aggregation import aggregate, accuracy_weights  # noqa: E402
from blmlcvar.copula import cbl_scenarios, fit_t_copula, simulate_t_copula  # noqa: E402
from blmlcvar.forecasting.common import make_windows, split_masks  # noqa: E402
from blmlcvar.optimization import scenario_cvar, solve_bl_cvar  # noqa: E402
from blmlcvar.prospect import pt_value  # noqa: E402


# --------------------------------------------------------------------- Eq. 4
def test_pt_threshold_65_is_038():
    assert pt_value(65) == pytest.approx(0.3817, abs=1e-4)          # Sect. 4.3


def test_pt_shape():
    assert pt_value(50) == 0
    assert pt_value(100) == pytest.approx(1.0)
    assert pt_value(0) == pytest.approx(-2.0)                          # -theta
    assert pt_value(40) < -abs(pt_value(60))                           # loss aversion


# --------------------------------------------------------------------- Eqs. 1-3
def _toy():
    idx = pd.date_range("2024-01-01", periods=3, freq="W-MON")
    actual = pd.DataFrame({"A": [10.0, 10.0, 10.0]}, index=idx)
    preds = {m: pd.DataFrame({"A": [10 + e] * 3}, index=idx) for m, e in
             zip(["m1", "m2", "m3", "m4", "m5"], [0.0, 1.0, 2.0, 3.0, 4.0])}
    return preds, actual


def test_weights_sum_to_one_and_use_previous_week():
    preds, actual = _toy()
    w = accuracy_weights(preds, actual)
    total = sum(w.values())
    np.testing.assert_allclose(total.to_numpy(), 1.0)
    assert w["m1"].iloc[0, 0] == pytest.approx(0.2)                   # first week: equal
    # errors 0..4, total 10 -> Re = 0, .1, .2, .3, .4 -> w = (1-Re)/4
    assert w["m1"].iloc[1, 0] == pytest.approx(0.25)
    assert w["m5"].iloc[1, 0] == pytest.approx(0.15)


def test_every_model_enters_the_aggregate():
    preds, actual = _toy()
    agg, w = aggregate(preds, actual)
    expected = sum(w[k].iloc[1, 0] * preds[k].iloc[1, 0] for k in preds)
    assert agg.iloc[1, 0] == pytest.approx(expected)


# --------------------------------------------------------------------- splits
def test_windows_and_split_have_no_overlap():
    idx = pd.date_range("2019-07-01", "2024-07-01", freq="W-MON")
    s = pd.Series(np.arange(len(idx), dtype=float), index=idx)
    X, y, d = make_windows(s, 30)
    assert X.shape[1] == 30 and np.all(X[:, -1] + 1 == y)            # input ends the week before
    tr, va, te = split_masks(d, "2022-12-26", "2023-06-26")
    assert not (tr & va).any() and not (va & te).any()
    assert d[te][0] == pd.Timestamp("2023-07-03") and d[te][-1] == pd.Timestamp("2024-07-01")


# --------------------------------------------------------------------- Eqs. 7-10
def test_bl_posterior_between_prior_and_views():
    cov = np.diag([0.001, 0.002])
    pi, Q = np.array([0.001, 0.001]), np.array([0.01, -0.01])
    mu, S = bl.posterior(cov, pi, Q, np.diag([1e-3, 1e-3]), tau=0.25)
    assert np.all((mu - pi) * (Q - pi) > 0) and np.all(np.abs(mu - pi) < np.abs(Q - pi))
    assert np.all(np.linalg.eigvalsh(S) > 0)


def test_more_accurate_views_get_more_weight():
    cov = np.diag([0.001, 0.001])
    pi, Q = np.zeros(2), np.array([0.01, 0.01])
    mu, _ = bl.posterior(cov, pi, Q, np.diag([1e-5, 1e-2]), tau=0.25)
    assert mu[0] > mu[1]                                              # smaller Omega -> closer to Q


def test_omega_rmae():
    idx = pd.date_range("2024-01-01", periods=4, freq="W-MON")
    a = pd.DataFrame({"A": [10.0] * 4}, index=idx)
    p = pd.DataFrame({"A": [11.0, 9.0, 11.0, 9.0]}, index=idx)
    assert bl.omega_from_rmae(p, a)[0, 0] == pytest.approx(0.1)


# --------------------------------------------------------------------- copula
def test_t_copula_recovers_dof():
    rng = np.random.default_rng(0)
    R = np.array([[1, .6, .3], [.6, 1, .4], [.3, .4, 1]])
    u = simulate_t_copula(R, 4.0, 3000, rng)
    z = pd.DataFrame(u)
    Rh, nu = fit_t_copula(z)
    assert 2.5 < nu < 7
    np.testing.assert_allclose(Rh, R, atol=0.08)


def test_cbl_scenarios_match_posterior_moments():
    rng = np.random.default_rng(1)
    scen = rng.standard_t(4, (20000, 3)) * 0.02
    mu = np.array([0.001, 0.002, 0.003])
    S = np.array([[4, 1, 0], [1, 3, 1], [0, 1, 2]]) * 1e-4
    r = cbl_scenarios(scen, mu, S)
    np.testing.assert_allclose(r.mean(0), mu, atol=1e-6)
    np.testing.assert_allclose(np.cov(r, rowvar=False), S, rtol=1e-6, atol=1e-10)


# --------------------------------------------------------------------- Eqs. 17-20
def test_cvar_lp_respects_constraints():
    rng = np.random.default_rng(2)
    n, S = 12, 4000
    scen = 0.002 + 0.03 * rng.standard_t(5, (S, n))
    mu = pd.Series(np.linspace(0.001, 0.004, n), index=[f"a{i}" for i in range(n)])
    esg = pd.DataFrame(rng.uniform(-0.5, 1, (n, 3)), index=mu.index)
    sol = solve_bl_cvar(mu, scen, 0.95, 0.08, 0.10, esg, 0.0, "CLARABEL")
    w = sol.weights
    assert w.sum() == pytest.approx(1, abs=1e-6) and w.max() <= 0.10 + 1e-6
    assert (esg.T @ w >= -1e-6).all()
    if not sol.fallback:
        assert scenario_cvar(w.to_numpy(), scen, 0.95) <= 0.08 + 2e-3
