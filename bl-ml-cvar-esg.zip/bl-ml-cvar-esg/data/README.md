# Data

## `tickers.csv`
The 63 Yahoo Finance tickers of the iShares Global Water UCITS ETF that were downloaded, and the 55 used in the paper (`included = 1`). The excluded tickers and the reasons for excluding them are:

| Ticker | Reason |
|---|---|
| VLTO, 3PN0.DU | short price history |
| 6368.T, 8936.TWO, 601369.SS, 603279.SS, 2083.SR | no LSEG ESG data |
| 6254.T | **reason to be confirmed by the authors** |

## Files you must provide in `data/raw/`

### `esg_scores.csv` (LSEG, July 2024, not redistributable)
```
asset,ESG Score,Environmental Pillar Score,Social Pillar Score,Governance Pillar Score
AWK,78.80,68.85,90.49,81.61
...
```
Scores go from 0 to 100. Both `,` and `;` work as separators. Step 4 writes the Prospect-Theory transformation of these scores to `data/processed/esg_pt.csv`.

### `shares_outstanding.csv`
```
ticker,shares
AWK,194700000
...
```
These shares are used to compute weekly market capitalisations in USD, which give the market weights `w_m` of Eq. (5). Record the source and the reference date used.

### `ecb_deposit_facility.csv`
The ECB deposit facility rate (annual %, step function), as exported from the ECB Data Portal:
```
date;deposit
18/09/2019;-0,50
...
```

## Generated in `data/processed/`
- `prices_local.csv` and `prices_usd.csv` contain weekly (Monday) adjusted closes. Gaps of up to 4 weeks are forward-filled. Nothing is back-filled.
- `currencies.csv` gives the listing currency of each ticker. Check the `.IL` tickers by hand.
- `esg_pt.csv` holds the PT-transformed scores.
